# World Origin MVP

**Thesis:** World Origin does not need to be a launchpad to test the core idea. Pump.fun handles coin creation, trading, fees, bonding curve and graduation. World Origin is the civilization/game layer attached to Pump.fun tokens.

## MVP loop
1. Launch token on Pump.fun.
2. Open World Origin and choose **Claim a World**.
3. Paste the token mint and connect the creator wallet.
4. Choose world name, biome and founding ethos.
5. World Origin creates the civilization page.
6. Next production layer: read Pump.fun/Solana activity and turn it into population, stage progression and history.

## What this build intentionally removes
- World Origin Anchor program
- custom bonding curve
- custom SPL token creation
- 2% World Origin trading fee
- Builder Treasury / $ORIGIN settlement
- custom DEX graduation

Those are post-traction features.

## What works in this static MVP
- New World Origin teal/black sci-fi branding
- Pump.fun launch CTA
- Solana browser-wallet connection (Phantom/Solflare/Backpack injection)
- Claim-world flow
- biome + ethos selection
- civilization pages
- local claim persistence for prototype/demo use
- sample World Atlas
- responsive mobile layout

## Production requirements before opening claims publicly
The current claim records use browser localStorage so the UX can be tested immediately. For a public release, claims should be persisted server-side and the founder must be verified. Recommended minimal verification:

1. Client requests a one-time nonce.
2. Connected wallet signs `Claim <mint> on World Origin: <nonce>`.
3. Server verifies the signature.
4. Server verifies that wallet is authorized to claim that Pump.fun mint (creator/approved ownership rule).
5. Unique constraint prevents a mint being claimed twice.
6. Save `mint`, founder wallet, world configuration, created_at and verification signature/hash.

Supabase is sufficient for the MVP database/API layer.

## $ORIGIN launch
After the Pump.fun launch, edit `web/app.js` and set:

```js
originMint: 'PASTE_ORIGIN_MINT_HERE'
```

The MVP does not require $ORIGIN to function. That is deliberate: $ORIGIN is the World Origin community/ecosystem token while the product proves demand before deeper utility is added.

## Run locally
Open `web/index.html` or serve `web/` with any static server.

## Deploy
The `web/` directory is static and can be deployed directly to Netlify.

## Token branding

Platform: **WORLD ORIGIN**  
Ecosystem token: **$ORIGIN**  
Tagline: **Every world has an origin.**
