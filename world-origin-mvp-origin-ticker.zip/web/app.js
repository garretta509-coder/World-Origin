const $ = (s) => document.querySelector(s);
const app = $('#app');

const CONFIG = {
  pumpCreate: 'https://pump.fun/create',
  pumpBase: 'https://pump.fun/coin/',
  originMint: '', // paste the $ORIGIN mint here after launch
  originTicker: 'ORIGIN'
};

const DEMO_WORLDS = [
  {id:'otter',mint:'demo-otter',name:'Otter Republic',ticker:'OTTER',biome:'Riverlands',ethos:'Builders',stage:'City',citizens:1842,mc:'$1.2M',age:'3d',health:91,structures:14,history:['Genesis — the first citizens arrived','The Great Harbor was raised','Population crossed 1,000 citizens','The settlement became a City']},
  {id:'frog',mint:'demo-frog',name:'Frog Kingdom',ticker:'FROG',biome:'Wetlands',ethos:'Explorers',stage:'Town',citizens:936,mc:'$684K',age:'2d',health:84,structures:9,history:['Genesis in the wetlands','The first farm was completed','Explorers mapped the eastern marsh','The settlement became a Town']},
  {id:'cat',mint:'demo-cat',name:'Cat Republic',ticker:'CAT',biome:'Highlands',ethos:'Traders',stage:'Village',citizens:412,mc:'$218K',age:'1d',health:72,structures:5,history:['Genesis on the high ridge','Citizens opened the first market','A watchtower was built']}
];

let wallet = localStorage.getItem('wo_wallet') || '';
let claims = JSON.parse(localStorage.getItem('wo_claims') || '[]');
let claimDraft = {mint:'',name:'',ticker:'',biome:'Riverlands',ethos:'Builders'};

function saveClaims(){ localStorage.setItem('wo_claims', JSON.stringify(claims)); }
function short(a){ return a ? `${a.slice(0,4)}…${a.slice(-4)}` : 'CONNECT WALLET'; }
function toast(msg){ const t=$('#toast'); if(!t)return; t.textContent=msg;t.classList.add('show');clearTimeout(window.__toast);window.__toast=setTimeout(()=>t.classList.remove('show'),2500); }
function escapeHtml(v=''){return String(v).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[c]));}
function route(page,id){ location.hash = page + (id?`/${id}`:''); render(); scrollTo(0,0); }
function pumpUrl(mint){ return CONFIG.pumpBase + encodeURIComponent(mint); }

async function connectWallet(){
  const providers=[window.phantom?.solana,window.solflare,window.backpack].filter(Boolean);
  if(!providers.length){ toast('Install Phantom, Solflare or Backpack to connect.'); return; }
  try{ const p=providers[0]; const r=await p.connect(); wallet=(r.publicKey||p.publicKey).toString(); localStorage.setItem('wo_wallet',wallet); render(); toast(`Connected ${short(wallet)}`); }
  catch(e){ toast('Wallet connection cancelled.'); }
}

function nav(){return `<nav class="nav"><button class="brand" onclick="route('home')"><span class="originMark">✦</span><span>WORLD <b>ORIGIN</b></span></button><div class="navlinks"><button onclick="route('explore')">EXPLORE</button><button onclick="route('claim')">CLAIM A WORLD</button><a href="${CONFIG.pumpCreate}" target="_blank" rel="noopener">LAUNCH ON PUMP ↗</a><button class="wallet" onclick="connectWallet()">${short(wallet)}</button></div></nav>`}
function footer(){return `<footer><div><span class="brandText">WORLD ORIGIN</span><span>Every world has an origin.</span></div><div><a href="${CONFIG.pumpCreate}" target="_blank" rel="noopener">Pump.fun ↗</a><span>MVP · SOLANA</span></div></footer>`}

function worldCard(w){return `<button class="worldCard" onclick="route('world','${escapeHtml(w.id)}')"><div class="planet ${w.biome.toLowerCase()}"><i></i><span>${w.stage}</span></div><div class="cardTop"><div><small>$${escapeHtml(w.ticker)}</small><h3>${escapeHtml(w.name)}</h3></div><span class="live">● LIVE</span></div><div class="metrics"><span><b>${escapeHtml(w.mc)}</b>MARKET CAP</span><span><b>${Number(w.citizens).toLocaleString()}</b>CITIZENS</span><span><b>${escapeHtml(w.age)}</b>AGE</span></div></button>`}
function allWorlds(){
  const user = claims.map((c,i)=>({id:`claim-${i}`, ...c,stage:'Settlement',citizens:1,mc:'—',age:'now',health:100,structures:1,history:['Genesis — this world was claimed on World Origin']}));
  return [...user,...DEMO_WORLDS];
}

function home(){return `${nav()}<main>
<section class="hero"><div class="heroBg"></div><div class="heroShade"></div><div class="heroCopy"><div class="kicker">THE CIVILIZATION LAYER FOR PUMP.FUN</div><h1>Every world<br>has an <em>origin.</em></h1><p>Launch a coin on Pump.fun. Claim its world. Turn a ticker into a civilization your community can watch grow.</p><div class="actions"><a class="primary" href="${CONFIG.pumpCreate}" target="_blank" rel="noopener">LAUNCH ON PUMP.FUN ↗</a><button class="secondary" onclick="route('claim')">CLAIM YOUR WORLD</button></div><div class="proof"><span>NO NEW LAUNCHPAD</span><span>NO TOKEN MIGRATION</span><span>YOUR COIN · ITS WORLD</span></div></div></section>
<section class="manifest"><div><span class="num">01</span><h2>Launch.</h2><p>Create your token where the market already is: Pump.fun.</p></div><div><span class="num">02</span><h2>Claim.</h2><p>Bring the mint to World Origin and found its civilization.</p></div><div><span class="num">03</span><h2>Evolve.</h2><p>Market activity and community milestones become visible history.</p></div></section>
<section class="worldSection"><div class="sectionHead"><div><div class="kicker">LIVE WORLDS</div><h2>Civilizations are forming.</h2></div><button class="textBtn" onclick="route('explore')">EXPLORE ALL →</button></div><div class="worldGrid">${allWorlds().slice(0,3).map(worldCard).join('')}</div></section>
<section class="originCta"><div class="ring"></div><div><div class="kicker">FOUND YOUR CIVILIZATION</div><h2>Your coin already has a market.<br>Give it a world.</h2><p>World Origin starts as the identity and game layer around Pump.fun tokens. The deeper onchain economy comes only if the community proves it wants it.</p><button class="primary" onclick="route('claim')">CLAIM A WORLD →</button></div></section>
</main>${footer()}`}

function explore(){const worlds=allWorlds();return `${nav()}<main class="page"><div class="pageHead"><div class="kicker">WORLD ATLAS</div><h1>Explore civilizations.</h1><p>Every world begins with a Solana token and grows into its own history.</p></div><div class="worldGrid">${worlds.map(worldCard).join('')}</div></main>${footer()}`}

function claim(){return `${nav()}<main class="claimPage"><div class="claimIntro"><div class="kicker">CLAIM A WORLD</div><h1>Bring your Pump.fun coin to life.</h1><p>For the MVP, Pump.fun remains the launchpad and market. World Origin becomes the persistent civilization attached to the coin.</p><div class="claimSteps"><span><b>1</b>Launch on Pump.fun</span><span><b>2</b>Paste the mint</span><span><b>3</b>Connect creator wallet</span><span><b>4</b>Found the world</span></div></div><form class="claimForm" onsubmit="submitClaim(event)"><label>PUMP.FUN TOKEN MINT<input id="mint" value="${escapeHtml(claimDraft.mint)}" placeholder="Paste Solana mint address" required /></label><div class="two"><label>WORLD NAME<input id="worldName" value="${escapeHtml(claimDraft.name)}" maxlength="32" placeholder="Otter Republic" required /></label><label>TICKER<input id="ticker" value="${escapeHtml(claimDraft.ticker)}" maxlength="10" placeholder="OTTER" required /></label></div><label>BIOME<div class="choices">${['Riverlands','Highlands','Wetlands','Desert','Forest','Coast'].map(x=>`<button type="button" class="choice ${claimDraft.biome===x?'on':''}" onclick="setDraft('biome','${x}')">${x}</button>`).join('')}</div></label><label>FOUNDING ETHOS<div class="choices">${['Builders','Explorers','Traders'].map(x=>`<button type="button" class="choice ${claimDraft.ethos===x?'on':''}" onclick="setDraft('ethos','${x}')">${x}</button>`).join('')}</div></label><div class="verify"><span class="verifyIcon">✦</span><div><b>Founder verification</b><p>${wallet?`Wallet ${short(wallet)} connected. MVP creates the world preview now; server-side creator verification is the next production step.`:'Connect the wallet that launched the Pump.fun coin. World Origin will use a signed message to verify the founder — never your private key.'}</p></div></div>${wallet?`<button class="primary full" type="submit">FOUND THIS WORLD →</button>`:`<button class="primary full" type="button" onclick="connectWallet()">CONNECT CREATOR WALLET</button>`}<a class="pumpLink" href="${CONFIG.pumpCreate}" target="_blank" rel="noopener">Haven't launched yet? Create the coin on Pump.fun ↗</a></form></main>${footer()}`}
function setDraft(k,v){claimDraft[k]=v;render();}
function submitClaim(e){e.preventDefault();if(!wallet){connectWallet();return;}const mint=$('#mint').value.trim(),name=$('#worldName').value.trim(),ticker=$('#ticker').value.trim().toUpperCase();if(mint.length<20){toast('Enter a valid Solana mint address.');return;}if(claims.some(c=>c.mint===mint)){toast('This mint already has a world in this MVP.');return;}claims.unshift({mint,name,ticker,biome:claimDraft.biome,ethos:claimDraft.ethos,founder:wallet});saveClaims();claimDraft={mint:'',name:'',ticker:'',biome:'Riverlands',ethos:'Builders'};route('world','claim-0');toast('Genesis complete. Your world has begun.');}

function worldPage(id){const w=allWorlds().find(x=>x.id===id);if(!w)return explore();const isDemo=w.mint.startsWith('demo-');return `${nav()}<main class="worldPage"><section class="worldHero"><div class="worldPlanet ${w.biome.toLowerCase()}"><div class="orbit"></div><div class="city"></div></div><div class="worldTitle"><div class="kicker">${escapeHtml(w.biome).toUpperCase()} · ${escapeHtml(w.ethos).toUpperCase()}</div><h1>${escapeHtml(w.name)}</h1><div class="ticker">$${escapeHtml(w.ticker)} <span>● ${escapeHtml(w.stage).toUpperCase()}</span></div><p>${isDemo?'A living demonstration of the World Origin civilization system.':'This civilization has just entered Genesis. Its story starts here.'}</p><div class="actions">${!isDemo?`<a class="primary" href="${pumpUrl(w.mint)}" target="_blank" rel="noopener">VIEW ON PUMP.FUN ↗</a>`:''}<button class="secondary" onclick="route('explore')">WORLD ATLAS</button></div></div></section><section class="worldStats"><div><b>${escapeHtml(w.mc)}</b><span>MARKET CAP</span></div><div><b>${Number(w.citizens).toLocaleString()}</b><span>CITIZENS</span></div><div><b>${w.structures}</b><span>STRUCTURES</span></div><div><b>${w.health}%</b><span>WORLD HEALTH</span></div></section><section class="worldBody"><div class="civilization"><div class="kicker">CIVILIZATION</div><h2>${escapeHtml(w.stage)}</h2><div class="settlement"><div class="terrain"></div>${Array.from({length:Math.max(3,Math.min(12,w.structures))},(_,i)=>`<i style="--x:${12+(i*19)%76}%;--y:${20+(i*27)%65}%;--s:${.65+(i%4)*.13}"></i>`).join('')}<span class="core">✦</span></div><div class="progress"><span style="width:${Math.min(100,20+w.structures*6)}%"></span></div><div class="stageLabels"><span>SETTLEMENT</span><span>VILLAGE</span><span>TOWN</span><span>CITY</span><span>REALM</span></div></div><aside class="history"><div class="kicker">PERMANENT HISTORY</div><h2>Chronicle</h2>${w.history.map((h,i)=>`<div class="event"><span>${String(i+1).padStart(2,'0')}</span><p>${escapeHtml(h)}</p></div>`).join('')}<div class="next"><b>Next MVP layer</b><p>Live Pump.fun stats → automatic population, stage progression and historical events.</p></div></aside></section></main>${footer()}`}

function render(){const raw=location.hash.replace('#','')||'home', [page,id]=raw.split('/'); if(page==='claim')app.innerHTML=claim();else if(page==='explore')app.innerHTML=explore();else if(page==='world')app.innerHTML=worldPage(id);else app.innerHTML=home();}
window.route=route;window.connectWallet=connectWallet;window.setDraft=setDraft;window.submitClaim=submitClaim;
render();
