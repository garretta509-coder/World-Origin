use anchor_lang::prelude::*;
use anchor_lang::system_program::{transfer, Transfer};
use anchor_lang::solana_program::pubkey;
use anchor_spl::associated_token::AssociatedToken;
use anchor_spl::token::{self, Mint, MintTo, Token, TokenAccount, Transfer as TokenTransfer};

// Replace after `anchor keys sync` / deployment.
declare_id!("11111111111111111111111111111111");

const PLATFORM_WALLET: Pubkey = pubkey!("46f4Kn4tEdvrzrxHfXw3JkkFBXoj9m956q7czYExNHdp");
const BPS_DENOM: u128 = 10_000;
const PLATFORM_FEE_BPS: u128 = 100;
const BUILDER_FEE_BPS: u128 = 100;
const TOKEN_DECIMALS: u8 = 6;
const GENESIS_SUPPLY: u64 = 1_000_000_000_000_000; // 1B tokens @ 6 decimals
const DEFAULT_VIRTUAL_SOL: u64 = 30_000_000_000; // 30 SOL
const DEFAULT_VIRTUAL_TOKEN: u64 = 1_073_000_000_000_000;
const DEFAULT_GRADUATION_SOL: u64 = 85_000_000_000; // configurable before mainnet

#[program]
pub mod worldfun {
    use super::*;

    pub fn initialize_protocol(ctx: Context<InitializeProtocol>, world_mint: Option<Pubkey>) -> Result<()> {
        require_keys_eq!(ctx.accounts.platform_wallet.key(), PLATFORM_WALLET, WorldError::InvalidPlatformWallet);
        let p = &mut ctx.accounts.protocol;
        p.authority = ctx.accounts.authority.key();
        p.platform_wallet = ctx.accounts.platform_wallet.key();
        p.world_mint = world_mint.unwrap_or_default();
        p.platform_fee_bps = PLATFORM_FEE_BPS as u16;
        p.builder_fee_bps = BUILDER_FEE_BPS as u16;
        p.graduation_sol = DEFAULT_GRADUATION_SOL;
        p.paused = false;
        p.bump = ctx.bumps.protocol;
        Ok(())
    }

    pub fn create_civilization(
        ctx: Context<CreateCivilization>,
        name: String,
        symbol: String,
        uri: String,
        biome: u8,
        ethos: u8,
    ) -> Result<()> {
        require!(!ctx.accounts.protocol.paused, WorldError::ProtocolPaused);
        require!(name.as_bytes().len() <= 32, WorldError::NameTooLong);
        require!(!symbol.is_empty() && symbol.as_bytes().len() <= 10, WorldError::SymbolInvalid);
        require!(uri.as_bytes().len() <= 200, WorldError::UriTooLong);

        let civ = &mut ctx.accounts.civilization;
        civ.mint = ctx.accounts.mint.key();
        civ.creator = ctx.accounts.creator.key();
        civ.name = name;
        civ.symbol = symbol;
        civ.uri = uri;
        civ.biome = biome;
        civ.ethos = ethos;
        civ.created_at = Clock::get()?.unix_timestamp;
        civ.builder_sol_pending = 0;
        civ.builder_world_balance = 0;
        civ.builder_world_spent = 0;
        civ.lifetime_volume_lamports = 0;
        civ.platform_fees_lamports = 0;
        civ.trade_count = 0;
        civ.world_level = 0;
        civ.graduated = false;
        civ.bump = ctx.bumps.civilization;

        ctx.accounts.builder_vault.bump = ctx.bumps.builder_vault;

        let curve = &mut ctx.accounts.curve;
        curve.mint = ctx.accounts.mint.key();
        curve.virtual_sol = DEFAULT_VIRTUAL_SOL;
        curve.virtual_token = DEFAULT_VIRTUAL_TOKEN;
        curve.real_sol = 0;
        curve.real_token = GENESIS_SUPPLY;
        curve.graduated = false;
        curve.bump = ctx.bumps.curve;

        let mint_key = ctx.accounts.mint.key();
        let signer: &[&[&[u8]]] = &[&[b"curve", mint_key.as_ref(), &[ctx.bumps.curve]]];
        token::mint_to(
            CpiContext::new_with_signer(
                ctx.accounts.token_program.to_account_info(),
                MintTo {
                    mint: ctx.accounts.mint.to_account_info(),
                    to: ctx.accounts.curve_token_vault.to_account_info(),
                    authority: ctx.accounts.curve.to_account_info(),
                },
                signer,
            ),
            GENESIS_SUPPLY,
        )?;
        Ok(())
    }

    pub fn buy(ctx: Context<Buy>, lamports_in: u64, min_tokens_out: u64) -> Result<()> {
        require!(!ctx.accounts.protocol.paused, WorldError::ProtocolPaused);
        require!(!ctx.accounts.curve.graduated, WorldError::AlreadyGraduated);
        require!(lamports_in > 0, WorldError::ZeroAmount);

        let platform_fee = fee(lamports_in, ctx.accounts.protocol.platform_fee_bps)?;
        let builder_fee = fee(lamports_in, ctx.accounts.protocol.builder_fee_bps)?;
        let curve_in = lamports_in.checked_sub(platform_fee).and_then(|x| x.checked_sub(builder_fee)).ok_or(WorldError::MathOverflow)?;
        let tokens_out = buy_quote(&ctx.accounts.curve, curve_in)?;
        require!(tokens_out >= min_tokens_out, WorldError::SlippageExceeded);
        require!(tokens_out <= ctx.accounts.curve.real_token, WorldError::InsufficientLiquidity);

        system_transfer(&ctx.accounts.buyer, &ctx.accounts.platform_wallet, &ctx.accounts.system_program, platform_fee)?;
        system_transfer(&ctx.accounts.buyer, &ctx.accounts.builder_vault, &ctx.accounts.system_program, builder_fee)?;
        system_transfer(&ctx.accounts.buyer, &ctx.accounts.curve, &ctx.accounts.system_program, curve_in)?;

        let mint_key = ctx.accounts.mint.key();
        let signer: &[&[&[u8]]] = &[&[b"curve", mint_key.as_ref(), &[ctx.accounts.curve.bump]]];
        token::transfer(
            CpiContext::new_with_signer(
                ctx.accounts.token_program.to_account_info(),
                TokenTransfer {
                    from: ctx.accounts.curve_token_vault.to_account_info(),
                    to: ctx.accounts.buyer_token_account.to_account_info(),
                    authority: ctx.accounts.curve.to_account_info(),
                },
                signer,
            ),
            tokens_out,
        )?;

        let curve = &mut ctx.accounts.curve;
        curve.virtual_sol = curve.virtual_sol.checked_add(curve_in).ok_or(WorldError::MathOverflow)?;
        curve.virtual_token = curve.virtual_token.checked_sub(tokens_out).ok_or(WorldError::MathOverflow)?;
        curve.real_sol = curve.real_sol.checked_add(curve_in).ok_or(WorldError::MathOverflow)?;
        curve.real_token = curve.real_token.checked_sub(tokens_out).ok_or(WorldError::MathOverflow)?;

        let civ = &mut ctx.accounts.civilization;
        civ.builder_sol_pending = civ.builder_sol_pending.checked_add(builder_fee).ok_or(WorldError::MathOverflow)?;
        civ.platform_fees_lamports = civ.platform_fees_lamports.checked_add(platform_fee).ok_or(WorldError::MathOverflow)?;
        civ.lifetime_volume_lamports = civ.lifetime_volume_lamports.checked_add(lamports_in).ok_or(WorldError::MathOverflow)?;
        civ.trade_count = civ.trade_count.checked_add(1).ok_or(WorldError::MathOverflow)?;
        civ.world_level = level_from_curve(curve);
        Ok(())
    }

    pub fn sell(ctx: Context<Sell>, tokens_in: u64, min_lamports_out: u64) -> Result<()> {
        require!(!ctx.accounts.protocol.paused, WorldError::ProtocolPaused);
        require!(!ctx.accounts.curve.graduated, WorldError::AlreadyGraduated);
        require!(tokens_in > 0, WorldError::ZeroAmount);
        let gross_sol = sell_quote(&ctx.accounts.curve, tokens_in)?;
        require!(gross_sol <= ctx.accounts.curve.real_sol, WorldError::InsufficientLiquidity);
        let platform_fee = fee(gross_sol, ctx.accounts.protocol.platform_fee_bps)?;
        let builder_fee = fee(gross_sol, ctx.accounts.protocol.builder_fee_bps)?;
        let user_sol = gross_sol.checked_sub(platform_fee).and_then(|x| x.checked_sub(builder_fee)).ok_or(WorldError::MathOverflow)?;
        require!(user_sol >= min_lamports_out, WorldError::SlippageExceeded);

        token::transfer(
            CpiContext::new(
                ctx.accounts.token_program.to_account_info(),
                TokenTransfer {
                    from: ctx.accounts.seller_token_account.to_account_info(),
                    to: ctx.accounts.curve_token_vault.to_account_info(),
                    authority: ctx.accounts.seller.to_account_info(),
                },
            ),
            tokens_in,
        )?;

        debit_program_lamports(&ctx.accounts.curve.to_account_info(), &ctx.accounts.seller.to_account_info(), user_sol)?;
        debit_program_lamports(&ctx.accounts.curve.to_account_info(), &ctx.accounts.platform_wallet.to_account_info(), platform_fee)?;
        debit_program_lamports(&ctx.accounts.curve.to_account_info(), &ctx.accounts.builder_vault.to_account_info(), builder_fee)?;

        let curve = &mut ctx.accounts.curve;
        curve.virtual_sol = curve.virtual_sol.checked_sub(gross_sol).ok_or(WorldError::MathOverflow)?;
        curve.virtual_token = curve.virtual_token.checked_add(tokens_in).ok_or(WorldError::MathOverflow)?;
        curve.real_sol = curve.real_sol.checked_sub(gross_sol).ok_or(WorldError::MathOverflow)?;
        curve.real_token = curve.real_token.checked_add(tokens_in).ok_or(WorldError::MathOverflow)?;

        let civ = &mut ctx.accounts.civilization;
        civ.builder_sol_pending = civ.builder_sol_pending.checked_add(builder_fee).ok_or(WorldError::MathOverflow)?;
        civ.platform_fees_lamports = civ.platform_fees_lamports.checked_add(platform_fee).ok_or(WorldError::MathOverflow)?;
        civ.lifetime_volume_lamports = civ.lifetime_volume_lamports.checked_add(gross_sol).ok_or(WorldError::MathOverflow)?;
        civ.trade_count = civ.trade_count.checked_add(1).ok_or(WorldError::MathOverflow)?;
        civ.world_level = level_from_curve(curve);
        Ok(())
    }

    // Marks builder SOL as settled after a verified swap adapter transfers $WORLD into the
    // civilization's locked Builder Treasury. In production this instruction must verify the
    // WORLD token vault delta and approved swap program/CPI; it is intentionally authority-gated
    // in this scaffold rather than pretending an unverified aggregator CPI is safe.
    pub fn record_builder_settlement(ctx: Context<RecordBuilderSettlement>, sol_spent: u64, world_received: u64) -> Result<()> {
        require_keys_eq!(ctx.accounts.authority.key(), ctx.accounts.protocol.authority, WorldError::Unauthorized);
        require!(sol_spent <= ctx.accounts.civilization.builder_sol_pending, WorldError::InsufficientBuilderBalance);
        let civ = &mut ctx.accounts.civilization;
        civ.builder_sol_pending = civ.builder_sol_pending.checked_sub(sol_spent).ok_or(WorldError::MathOverflow)?;
        civ.builder_world_balance = civ.builder_world_balance.checked_add(world_received).ok_or(WorldError::MathOverflow)?;
        Ok(())
    }

    pub fn spend_builder_world(ctx: Context<SpendBuilderWorld>, amount: u64, new_world_level: u8) -> Result<()> {
        require_keys_eq!(ctx.accounts.creator.key(), ctx.accounts.civilization.creator, WorldError::Unauthorized);
        require!(amount <= ctx.accounts.civilization.builder_world_balance, WorldError::InsufficientBuilderBalance);
        let civ = &mut ctx.accounts.civilization;
        civ.builder_world_balance = civ.builder_world_balance.checked_sub(amount).ok_or(WorldError::MathOverflow)?;
        civ.builder_world_spent = civ.builder_world_spent.checked_add(amount).ok_or(WorldError::MathOverflow)?;
        civ.world_level = civ.world_level.max(new_world_level.min(4));
        Ok(())
    }

    pub fn graduate(ctx: Context<Graduate>) -> Result<()> {
        require!(!ctx.accounts.curve.graduated, WorldError::AlreadyGraduated);
        require!(ctx.accounts.curve.real_sol >= ctx.accounts.protocol.graduation_sol, WorldError::GraduationNotReady);
        ctx.accounts.curve.graduated = true;
        ctx.accounts.civilization.graduated = true;
        ctx.accounts.civilization.world_level = 4;
        // Production V7: CPI into selected canonical DEX migration adapter and transfer
        // curve token/SOL inventory atomically. Until that CPI is implemented, graduation
        // is a state gate and cannot be represented as completed DEX migration.
        Ok(())
    }
}

fn fee(amount: u64, bps: u16) -> Result<u64> {
    Ok(((amount as u128).checked_mul(bps as u128).ok_or(WorldError::MathOverflow)? / BPS_DENOM) as u64)
}
fn buy_quote(curve: &Curve, curve_in: u64) -> Result<u64> {
    let k = (curve.virtual_sol as u128).checked_mul(curve.virtual_token as u128).ok_or(WorldError::MathOverflow)?;
    let new_sol = (curve.virtual_sol as u128).checked_add(curve_in as u128).ok_or(WorldError::MathOverflow)?;
    let new_token = k.checked_div(new_sol).ok_or(WorldError::MathOverflow)?;
    u64::try_from((curve.virtual_token as u128).checked_sub(new_token).ok_or(WorldError::MathOverflow)?).map_err(|_| error!(WorldError::MathOverflow))
}
fn sell_quote(curve: &Curve, tokens_in: u64) -> Result<u64> {
    let k = (curve.virtual_sol as u128).checked_mul(curve.virtual_token as u128).ok_or(WorldError::MathOverflow)?;
    let new_token = (curve.virtual_token as u128).checked_add(tokens_in as u128).ok_or(WorldError::MathOverflow)?;
    let new_sol = k.checked_div(new_token).ok_or(WorldError::MathOverflow)?;
    u64::try_from((curve.virtual_sol as u128).checked_sub(new_sol).ok_or(WorldError::MathOverflow)?).map_err(|_| error!(WorldError::MathOverflow))
}
fn level_from_curve(curve: &Curve) -> u8 {
    match curve.real_sol {
        0..=4_999_999_999 => 0,
        5_000_000_000..=14_999_999_999 => 1,
        15_000_000_000..=29_999_999_999 => 2,
        30_000_000_000..=59_999_999_999 => 3,
        _ => 4,
    }
}
fn system_transfer<'info>(from: &Signer<'info>, to: &AccountInfo<'info>, system: &Program<'info, System>, amount: u64) -> Result<()> {
    if amount == 0 { return Ok(()); }
    transfer(CpiContext::new(system.to_account_info(), Transfer { from: from.to_account_info(), to: to.clone() }), amount)
}
fn debit_program_lamports(from: &AccountInfo, to: &AccountInfo, amount: u64) -> Result<()> {
    if amount == 0 { return Ok(()); }
    let min = Rent::get()?.minimum_balance(from.data_len());
    require!(from.lamports().saturating_sub(amount) >= min, WorldError::InsufficientLiquidity);
    **from.try_borrow_mut_lamports()? = from.lamports().checked_sub(amount).ok_or(WorldError::MathOverflow)?;
    **to.try_borrow_mut_lamports()? = to.lamports().checked_add(amount).ok_or(WorldError::MathOverflow)?;
    Ok(())
}

#[derive(Accounts)]
pub struct InitializeProtocol<'info> {
    #[account(mut)] pub authority: Signer<'info>,
    /// CHECK: public SOL fee recipient, pinned in client/config at initialization.
    pub platform_wallet: UncheckedAccount<'info>,
    #[account(init, payer=authority, space=8+Protocol::INIT_SPACE, seeds=[b"protocol"], bump)]
    pub protocol: Account<'info, Protocol>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct CreateCivilization<'info> {
    #[account(mut)] pub creator: Signer<'info>,
    #[account(seeds=[b"protocol"], bump=protocol.bump)] pub protocol: Account<'info, Protocol>,
    #[account(init, payer=creator, mint::decimals=TOKEN_DECIMALS, mint::authority=curve, mint::freeze_authority=curve)]
    pub mint: Account<'info, Mint>,
    #[account(init, payer=creator, space=8+Civilization::INIT_SPACE, seeds=[b"civilization",mint.key().as_ref()], bump)]
    pub civilization: Account<'info, Civilization>,
    #[account(init, payer=creator, space=8+Curve::INIT_SPACE, seeds=[b"curve",mint.key().as_ref()], bump)]
    pub curve: Account<'info, Curve>,
    #[account(init, payer=creator, space=8+BuilderVault::INIT_SPACE, seeds=[b"builder-vault",mint.key().as_ref()], bump)]
    pub builder_vault: Account<'info, BuilderVault>,
    #[account(init, payer=creator, associated_token::mint=mint, associated_token::authority=curve)]
    pub curve_token_vault: Account<'info, TokenAccount>,
    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
    pub rent: Sysvar<'info, Rent>,
}

#[derive(Accounts)]
pub struct Buy<'info> {
    #[account(mut)] pub buyer: Signer<'info>,
    #[account(seeds=[b"protocol"], bump=protocol.bump, has_one=platform_wallet)] pub protocol: Account<'info, Protocol>,
    /// CHECK: validated by protocol.has_one
    #[account(mut)] pub platform_wallet: UncheckedAccount<'info>,
    pub mint: Account<'info, Mint>,
    #[account(mut, seeds=[b"civilization",mint.key().as_ref()], bump=civilization.bump)] pub civilization: Account<'info, Civilization>,
    #[account(mut, seeds=[b"curve",mint.key().as_ref()], bump=curve.bump)] pub curve: Account<'info, Curve>,
    #[account(mut, seeds=[b"builder-vault",mint.key().as_ref()], bump=builder_vault.bump)] pub builder_vault: Account<'info, BuilderVault>,
    #[account(mut, associated_token::mint=mint, associated_token::authority=curve)] pub curve_token_vault: Account<'info, TokenAccount>,
    #[account(mut, token::mint=mint, token::authority=buyer)] pub buyer_token_account: Account<'info, TokenAccount>,
    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct Sell<'info> {
    #[account(mut)] pub seller: Signer<'info>,
    #[account(seeds=[b"protocol"], bump=protocol.bump, has_one=platform_wallet)] pub protocol: Account<'info, Protocol>,
    /// CHECK: validated by protocol.has_one
    #[account(mut)] pub platform_wallet: UncheckedAccount<'info>,
    pub mint: Account<'info, Mint>,
    #[account(mut, seeds=[b"civilization",mint.key().as_ref()], bump=civilization.bump)] pub civilization: Account<'info, Civilization>,
    #[account(mut, seeds=[b"curve",mint.key().as_ref()], bump=curve.bump)] pub curve: Account<'info, Curve>,
    #[account(mut, seeds=[b"builder-vault",mint.key().as_ref()], bump=builder_vault.bump)] pub builder_vault: Account<'info, BuilderVault>,
    #[account(mut, associated_token::mint=mint, associated_token::authority=curve)] pub curve_token_vault: Account<'info, TokenAccount>,
    #[account(mut, token::mint=mint, token::authority=seller)] pub seller_token_account: Account<'info, TokenAccount>,
    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct RecordBuilderSettlement<'info> {
    pub authority: Signer<'info>,
    #[account(seeds=[b"protocol"], bump=protocol.bump)] pub protocol: Account<'info, Protocol>,
    pub mint: Account<'info, Mint>,
    #[account(mut, seeds=[b"civilization",mint.key().as_ref()], bump=civilization.bump)] pub civilization: Account<'info, Civilization>,
}

#[derive(Accounts)]
pub struct SpendBuilderWorld<'info> {
    pub creator: Signer<'info>,
    pub mint: Account<'info, Mint>,
    #[account(mut, seeds=[b"civilization",mint.key().as_ref()], bump=civilization.bump)] pub civilization: Account<'info, Civilization>,
}

#[derive(Accounts)]
pub struct Graduate<'info> {
    pub caller: Signer<'info>,
    #[account(seeds=[b"protocol"], bump=protocol.bump)] pub protocol: Account<'info, Protocol>,
    pub mint: Account<'info, Mint>,
    #[account(mut, seeds=[b"civilization",mint.key().as_ref()], bump=civilization.bump)] pub civilization: Account<'info, Civilization>,
    #[account(mut, seeds=[b"curve",mint.key().as_ref()], bump=curve.bump)] pub curve: Account<'info, Curve>,
}

#[account]
#[derive(InitSpace)]
pub struct Protocol {
    pub authority: Pubkey,
    pub platform_wallet: Pubkey,
    pub world_mint: Pubkey,
    pub platform_fee_bps: u16,
    pub builder_fee_bps: u16,
    pub graduation_sol: u64,
    pub paused: bool,
    pub bump: u8,
}

#[account]
#[derive(InitSpace)]
pub struct Civilization {
    pub mint: Pubkey,
    pub creator: Pubkey,
    #[max_len(32)] pub name: String,
    #[max_len(10)] pub symbol: String,
    #[max_len(200)] pub uri: String,
    pub biome: u8,
    pub ethos: u8,
    pub created_at: i64,
    pub builder_sol_pending: u64,
    pub builder_world_balance: u64,
    pub builder_world_spent: u64,
    pub lifetime_volume_lamports: u64,
    pub platform_fees_lamports: u64,
    pub trade_count: u64,
    pub world_level: u8,
    pub graduated: bool,
    pub bump: u8,
}

#[account]
#[derive(InitSpace)]
pub struct Curve {
    pub mint: Pubkey,
    pub virtual_sol: u64,
    pub virtual_token: u64,
    pub real_sol: u64,
    pub real_token: u64,
    pub graduated: bool,
    pub bump: u8,
}

#[account]
#[derive(InitSpace)]
pub struct BuilderVault { pub bump: u8 }

#[error_code]
pub enum WorldError {
    #[msg("Protocol is paused")] ProtocolPaused,
    #[msg("Amount must be greater than zero")] ZeroAmount,
    #[msg("Arithmetic overflow")] MathOverflow,
    #[msg("Trade exceeds available curve liquidity")] InsufficientLiquidity,
    #[msg("Slippage tolerance exceeded")] SlippageExceeded,
    #[msg("Civilization already graduated")] AlreadyGraduated,
    #[msg("Graduation threshold has not been reached")] GraduationNotReady,
    #[msg("Unauthorized")] Unauthorized,
    #[msg("Insufficient Builder Treasury balance")] InsufficientBuilderBalance,
    #[msg("Civilization name is too long")] NameTooLong,
    #[msg("Token symbol is invalid")] SymbolInvalid,
    #[msg("Metadata URI is too long")] UriTooLong,
    #[msg("Platform wallet does not match WORLD.FUN configuration")] InvalidPlatformWallet,
}
