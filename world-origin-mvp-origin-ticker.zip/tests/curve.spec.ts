import { expect } from "chai";
import { quoteBuy, quoteSell, CurveState } from "../client/protocol";

describe("WORLD.FUN curve economics", () => {
  const state: CurveState = {
    virtualSol: 30_000_000_000n,
    virtualToken: 1_073_000_000_000_000n,
    realSol: 20_000_000_000n,
    realToken: 800_000_000_000_000n,
  };

  it("splits a buy into 1% platform + 1% builder + 98% curve", () => {
    const q = quoteBuy(state, 1_000_000_000n);
    expect(q.platformFee).eq(10_000_000n);
    expect(q.builderFee).eq(10_000_000n);
    expect(q.curveSol).eq(980_000_000n);
    expect(q.userTokens > 0n).eq(true);
  });

  it("deducts 2% from gross sell proceeds", () => {
    const q = quoteSell(state, 1_000_000_000_000n);
    expect(q.platformFee + q.builderFee + q.userSol).eq(q.grossSol);
    expect(q.platformFee).eq(q.grossSol / 100n);
    expect(q.builderFee).eq(q.grossSol / 100n);
  });

  it("larger buys return proportionally fewer tokens due to price impact", () => {
    const small = quoteBuy(state, 100_000_000n);
    const large = quoteBuy(state, 1_000_000_000n);
    expect(large.userTokens < small.userTokens * 10n).eq(true);
  });
});
