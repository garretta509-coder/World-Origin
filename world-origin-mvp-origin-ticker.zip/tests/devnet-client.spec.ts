import { expect } from 'chai';
import { withSlippage, quoteBuyWithSlippage, quoteSellWithSlippage } from '../client/devnet';
const state={virtualSol:30_000_000_000n,virtualToken:1_073_000_000_000_000n,realSol:10_000_000_000n,realToken:900_000_000_000_000n};
describe('devnet client guards',()=>{
  it('applies slippage floors',()=>expect(withSlippage(10000n,300n)).eq(9700n));
  it('builds protected buy quote',()=>{const q=quoteBuyWithSlippage(state,1_000_000_000n);expect(q.minTokensOut<q.userTokens).eq(true)});
  it('builds protected sell quote',()=>{const q=quoteSellWithSlippage(state,1_000_000n);expect(q.minLamportsOut<q.userSol).eq(true)});
});
