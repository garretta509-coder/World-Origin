import { getDevnetHealth, deployment } from '../client/devnet';
const h=await getDevnetHealth();
console.log(JSON.stringify({cluster:deployment.cluster,programId:deployment.programId,...h},null,2));
