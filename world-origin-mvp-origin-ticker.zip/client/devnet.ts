import {
  address, createSolanaRpc, createSolanaRpcSubscriptions,
  getProgramDerivedAddress, getAddressEncoder, getUtf8Encoder,
} from '@solana/kit';
import { WORLD_FUN, quoteBuy, quoteSell, type CurveState } from './protocol';

export const DEVNET_RPC = 'https://api.devnet.solana.com';
export const DEVNET_WS = 'wss://api.devnet.solana.com';

export type WorldFunDeployment = {
  cluster: 'devnet' | 'mainnet-beta';
  programId: string | null;
  platformWallet: string;
  worldMint: string | null;
};

export const deployment: WorldFunDeployment = {
  cluster: 'devnet',
  programId: null,
  platformWallet: WORLD_FUN.platformWallet,
  worldMint: WORLD_FUN.worldMint,
};

export const rpc = createSolanaRpc(DEVNET_RPC);
export const rpcSubscriptions = createSolanaRpcSubscriptions(DEVNET_WS);

const utf8 = getUtf8Encoder();
const addr = getAddressEncoder();
function requireProgramId() {
  if (!deployment.programId) throw new Error('WORLD.FUN devnet program is not deployed/configured');
  return address(deployment.programId);
}

export async function deriveWorldAddresses(mint: string) {
  const program = requireProgramId();
  const mintAddress = address(mint);
  const [protocol] = await getProgramDerivedAddress({ programAddress: program, seeds: [utf8.encode('protocol')] });
  const [civilization] = await getProgramDerivedAddress({ programAddress: program, seeds: [utf8.encode('civilization'), addr.encode(mintAddress)] });
  const [curve] = await getProgramDerivedAddress({ programAddress: program, seeds: [utf8.encode('curve'), addr.encode(mintAddress)] });
  const [builderVault] = await getProgramDerivedAddress({ programAddress: program, seeds: [utf8.encode('builder-vault'), addr.encode(mintAddress)] });
  return { protocol, civilization, curve, builderVault };
}

export function withSlippage(amount: bigint, bps = 300n) {
  if (bps < 0n || bps >= 10_000n) throw new Error('Invalid slippage bps');
  return amount * (10_000n - bps) / 10_000n;
}

export function quoteBuyWithSlippage(state: CurveState, lamportsIn: bigint, slippageBps = 300n) {
  const quote = quoteBuy(state, lamportsIn);
  return { ...quote, minTokensOut: withSlippage(quote.userTokens, slippageBps) };
}
export function quoteSellWithSlippage(state: CurveState, tokensIn: bigint, slippageBps = 300n) {
  const quote = quoteSell(state, tokensIn);
  return { ...quote, minLamportsOut: withSlippage(quote.userSol, slippageBps) };
}

export async function getDevnetHealth() {
  const [slot, blockHeight] = await Promise.all([
    rpc.getSlot({ commitment: 'confirmed' }).send(),
    rpc.getBlockHeight({ commitment: 'confirmed' }).send(),
  ]);
  return { slot, blockHeight };
}
