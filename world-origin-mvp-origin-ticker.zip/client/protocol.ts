export const WORLD_FUN = {
  platformWallet: "46f4Kn4tEdvrzrxHfXw3JkkFBXoj9m956q7czYExNHdp",
  platformFeeBps: 100n,
  builderFeeBps: 100n,
  feeDenominator: 10_000n,
  worldMint: null as string | null,
  cluster: "devnet" as "devnet" | "mainnet-beta",
};

export type CurveState = {
  virtualSol: bigint;
  virtualToken: bigint;
  realSol: bigint;
  realToken: bigint;
};

export type BuyQuote = {
  userTokens: bigint;
  curveSol: bigint;
  platformFee: bigint;
  builderFee: bigint;
  totalSol: bigint;
};

export type SellQuote = {
  userSol: bigint;
  grossSol: bigint;
  platformFee: bigint;
  builderFee: bigint;
  tokensIn: bigint;
};

const fee = (amount: bigint, bps: bigint) => amount * bps / WORLD_FUN.feeDenominator;

export function quoteBuy(state: CurveState, totalSol: bigint): BuyQuote {
  if (totalSol <= 0n) throw new Error("SOL input must be positive");
  const platformFee = fee(totalSol, WORLD_FUN.platformFeeBps);
  const builderFee = fee(totalSol, WORLD_FUN.builderFeeBps);
  const curveSol = totalSol - platformFee - builderFee;
  const k = state.virtualSol * state.virtualToken;
  const newVirtualSol = state.virtualSol + curveSol;
  const newVirtualToken = k / newVirtualSol;
  const userTokens = state.virtualToken - newVirtualToken;
  if (userTokens <= 0n || userTokens > state.realToken) throw new Error("Insufficient curve inventory");
  return { userTokens, curveSol, platformFee, builderFee, totalSol };
}

export function quoteSell(state: CurveState, tokensIn: bigint): SellQuote {
  if (tokensIn <= 0n) throw new Error("Token input must be positive");
  const k = state.virtualSol * state.virtualToken;
  const newVirtualToken = state.virtualToken + tokensIn;
  const newVirtualSol = k / newVirtualToken;
  const grossSol = state.virtualSol - newVirtualSol;
  if (grossSol <= 0n || grossSol > state.realSol) throw new Error("Insufficient curve SOL liquidity");
  const platformFee = fee(grossSol, WORLD_FUN.platformFeeBps);
  const builderFee = fee(grossSol, WORLD_FUN.builderFeeBps);
  const userSol = grossSol - platformFee - builderFee;
  return { userSol, grossSol, platformFee, builderFee, tokensIn };
}

export interface WorldFunProgramAdapter {
  initializeProtocol(): Promise<string>;
  createCivilization(input: { name: string; symbol: string; uri: string; biome: number; ethos: number }): Promise<{ signature: string; mint: string }>;
  buy(mint: string, lamportsIn: bigint, minTokensOut: bigint): Promise<string>;
  sell(mint: string, tokensIn: bigint, minLamportsOut: bigint): Promise<string>;
  settleBuilderFees(mint: string, minWorldOut: bigint): Promise<string>;
  graduate(mint: string): Promise<string>;
}

export const seeds = {
  protocol: () => ["protocol"],
  civilization: (mint: string) => ["civilization", mint],
  curve: (mint: string) => ["curve", mint],
  solVault: (mint: string) => ["sol-vault", mint],
  builderVault: (mint: string) => ["builder-vault", mint],
  tokenVault: (mint: string) => ["token-vault", mint],
};
