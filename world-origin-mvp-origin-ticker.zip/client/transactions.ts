import type { CurveState } from './protocol';
import { deployment, deriveWorldAddresses, quoteBuyWithSlippage, quoteSellWithSlippage } from './devnet';

export type GenesisInput = { name:string; symbol:string; uri:string; biome:number; ethos:number };
export type PreparedAction = {
  kind:'genesis'|'buy'|'sell';
  programId:string;
  mint?:string;
  accounts:Record<string,string>;
  args:Record<string,string|number>;
  warnings:string[];
};
function programId(){ if(!deployment.programId) throw new Error('Deploy WORLD.FUN to devnet and configure programId first'); return deployment.programId; }

/**
 * Serializable transaction intents. The production bundler maps these to generated Anchor/IDL
 * instruction encoders. Keeping the intent layer separate makes every account and slippage bound
 * inspectable before a wallet signs.
 */
export async function prepareGenesis(creator:string, mint:string, input:GenesisInput):Promise<PreparedAction>{
  const a=await deriveWorldAddresses(mint);
  return {kind:'genesis',programId:programId(),mint,accounts:{creator,protocol:String(a.protocol),civilization:String(a.civilization),curve:String(a.curve),builderVault:String(a.builderVault)},args:input,warnings:['Mint must be a fresh signer account.','Metadata CPI is not implemented in V7 scaffold; Civilization.uri remains canonical until added.']};
}
export async function prepareBuy(buyer:string,mint:string,state:CurveState,lamportsIn:bigint,slippageBps=300n):Promise<PreparedAction>{
  const a=await deriveWorldAddresses(mint),q=quoteBuyWithSlippage(state,lamportsIn,slippageBps);
  return {kind:'buy',programId:programId(),mint,accounts:{buyer,platformWallet:deployment.platformWallet,protocol:String(a.protocol),civilization:String(a.civilization),curve:String(a.curve),builderVault:String(a.builderVault)},args:{lamportsIn:lamportsIn.toString(),minTokensOut:q.minTokensOut.toString(),slippageBps:Number(slippageBps)},warnings:['Client must create buyer ATA when absent.']};
}
export async function prepareSell(seller:string,mint:string,state:CurveState,tokensIn:bigint,slippageBps=300n):Promise<PreparedAction>{
  const a=await deriveWorldAddresses(mint),q=quoteSellWithSlippage(state,tokensIn,slippageBps);
  return {kind:'sell',programId:programId(),mint,accounts:{seller,platformWallet:deployment.platformWallet,protocol:String(a.protocol),civilization:String(a.civilization),curve:String(a.curve),builderVault:String(a.builderVault)},args:{tokensIn:tokensIn.toString(),minLamportsOut:q.minLamportsOut.toString(),slippageBps:Number(slippageBps)},warnings:[]};
}
