/** Minimal Wallet Standard bridge. No private keys ever enter WORLD.FUN. */
export type WalletAccountLike = { address: string; chains?: readonly string[] };
export type StandardWalletLike = {
  name: string;
  accounts: readonly WalletAccountLike[];
  features: Record<string, any>;
};

export function discoverSolanaWallets(): StandardWalletLike[] {
  const nav: any = globalThis.navigator;
  // Modern wallets expose Wallet Standard through registered-wallet libraries in a bundled app.
  // This fallback also recognizes injected providers for the static prototype shell.
  const injected = [
    ['Phantom', nav?.phantom?.solana], ['Solflare', nav?.solflare], ['Backpack', nav?.backpack],
  ].filter(([,p]) => p);
  return injected.map(([name,p]: any) => ({
    name, accounts: p.publicKey ? [{address:p.publicKey.toString(), chains:['solana:devnet']}] : [],
    features: { injectedProvider:p }
  }));
}

export async function connectInjectedWallet(wallet: StandardWalletLike) {
  const provider = wallet.features.injectedProvider;
  if (!provider?.connect) throw new Error(`${wallet.name} does not expose a connect feature`);
  const result = await provider.connect();
  const address = result?.publicKey?.toString?.() || provider.publicKey?.toString?.();
  if (!address) throw new Error('Wallet connected without a public address');
  return { wallet, address, provider };
}

export async function signAndSendInjected(provider: any, transaction: any) {
  if (!provider?.signAndSendTransaction) throw new Error('Wallet cannot sign and send transactions');
  const result = await provider.signAndSendTransaction(transaction);
  return result?.signature || result;
}
