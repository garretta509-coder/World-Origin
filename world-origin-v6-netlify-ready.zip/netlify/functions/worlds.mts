import { getStore, getDeployStore } from "@netlify/blobs";
import type { Config, Context } from "@netlify/functions";
import { createPublicKey, verify as verifySignature } from "node:crypto";

const STORE = "world-origin-worlds";
const ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";

function base58Decode(input: string): Uint8Array {
  let bytes = [0];
  for (const ch of input) {
    const value = ALPHABET.indexOf(ch);
    if (value < 0) throw new Error("Invalid base58");
    let carry = value;
    for (let j = 0; j < bytes.length; j++) {
      const x = bytes[j] * 58 + carry;
      bytes[j] = x & 255;
      carry = x >> 8;
    }
    while (carry) { bytes.push(carry & 255); carry >>= 8; }
  }
  for (let i = 0; i < input.length - 1 && input[i] === "1"; i++) bytes.push(0);
  return new Uint8Array(bytes.reverse());
}

function store() {
  const prod = Netlify.context?.deploy?.context === "production";
  return prod ? getStore(STORE, { consistency: "strong" }) : getDeployStore(STORE);
}

function json(data: unknown, status = 200) {
  return Response.json(data, { status, headers: { "Cache-Control": "no-store" } });
}

function cleanText(v: unknown, max: number) {
  return String(v ?? "").replace(/[<>]/g, "").trim().slice(0, max);
}

function validMint(v: string) {
  try { return base58Decode(v).length === 32; } catch { return false; }
}

function verifyWallet(message: string, wallet: string, signatureB64: string) {
  const raw = base58Decode(wallet);
  if (raw.length !== 32) return false;
  const prefix = Buffer.from("302a300506032b6570032100", "hex");
  const key = createPublicKey({ key: Buffer.concat([prefix, Buffer.from(raw)]), format: "der", type: "spki" });
  return verifySignature(null, Buffer.from(message), key, Buffer.from(signatureB64, "base64"));
}

export default async (req: Request, _context: Context) => {
  const s = store();
  const url = new URL(req.url);

  if (req.method === "GET") {
    const mint = url.searchParams.get("mint");
    if (mint) {
      const world = await s.get(`world/${mint}`, { type: "json" });
      return world ? json(world) : json({ error: "World not found" }, 404);
    }
    const { blobs } = await s.list({ prefix: "world/" });
    const worlds = (await Promise.all(blobs.slice(0, 100).map(b => s.get(b.key, { type: "json" })))).filter(Boolean);
    worlds.sort((a: any, b: any) => Date.parse(b.createdAt || 0) - Date.parse(a.createdAt || 0));
    return json({ worlds });
  }

  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  let body: any;
  try { body = await req.json(); } catch { return json({ error: "Invalid JSON" }, 400); }

  const mint = cleanText(body?.world?.mint, 60);
  const wallet = cleanText(body?.wallet, 60);
  const timestamp = Number(body?.timestamp);
  const signature = String(body?.signature || "");
  if (!validMint(mint) || !validMint(wallet)) return json({ error: "Invalid mint or wallet" }, 400);
  if (!Number.isFinite(timestamp) || Math.abs(Date.now() - timestamp) > 5 * 60_000) return json({ error: "Claim signature expired" }, 400);

  const message = `WORLD ORIGIN CLAIM\nMint:${mint}\nWallet:${wallet}\nTimestamp:${timestamp}`;
  try { if (!verifyWallet(message, wallet, signature)) return json({ error: "Wallet signature could not be verified" }, 401); }
  catch { return json({ error: "Wallet signature could not be verified" }, 401); }

  const existing = await s.get(`world/${mint}`, { type: "json" });
  if (existing && existing.founder !== wallet) return json({ error: "This world has already been claimed" }, 409);

  const allowedBiomes = ["Riverlands","Highlands","Wetlands","Desert","Forest","Coast"];
  const allowedEthos = ["Builders","Explorers","Traders"];
  const world = {
    mint,
    name: cleanText(body.world.name, 32),
    ticker: cleanText(body.world.ticker, 10).toUpperCase(),
    biome: allowedBiomes.includes(body.world.biome) ? body.world.biome : "Riverlands",
    ethos: allowedEthos.includes(body.world.ethos) ? body.world.ethos : "Builders",
    founder: wallet,
    createdAt: existing?.createdAt || new Date().toISOString(),
    verifiedClaim: true
  };
  if (!world.name || !world.ticker) return json({ error: "Name and ticker are required" }, 400);
  await s.setJSON(`world/${mint}`, world);
  return json({ world }, existing ? 200 : 201);
};

export const config: Config = { path: "/api/worlds" };
