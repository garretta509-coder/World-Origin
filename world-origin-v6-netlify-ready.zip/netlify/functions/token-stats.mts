import type { Config, Context } from "@netlify/functions";

function json(data: unknown, status = 200) {
  return Response.json(data, { status, headers: { "Cache-Control": "public, max-age=20, s-maxage=20" } });
}

export default async (req: Request, _context: Context) => {
  const mint = new URL(req.url).searchParams.get("mint") || "";
  if (!/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(mint)) return json({ error: "Invalid mint" }, 400);
  try {
    const r = await fetch(`https://api.dexscreener.com/latest/dex/tokens/${encodeURIComponent(mint)}`, { headers: { Accept: "application/json" } });
    if (!r.ok) return json({ available: false, source: "DexScreener" });
    const data: any = await r.json();
    const pairs = Array.isArray(data.pairs) ? data.pairs.filter((p: any) => p.chainId === "solana") : [];
    if (!pairs.length) return json({ available: false, source: "DexScreener" });
    pairs.sort((a: any,b: any)=>(Number(b.liquidity?.usd)||0)-(Number(a.liquidity?.usd)||0));
    const p = pairs[0];
    return json({
      available: true,
      source: "DexScreener",
      pairUrl: p.url || null,
      dexId: p.dexId || null,
      priceUsd: Number(p.priceUsd) || 0,
      marketCap: Number(p.marketCap || p.fdv) || 0,
      liquidityUsd: Number(p.liquidity?.usd) || 0,
      volume24h: Number(p.volume?.h24) || 0,
      volume1h: Number(p.volume?.h1) || 0,
      volume5m: Number(p.volume?.m5) || 0,
      buys24h: Number(p.txns?.h24?.buys) || 0,
      sells24h: Number(p.txns?.h24?.sells) || 0,
      buys1h: Number(p.txns?.h1?.buys) || 0,
      sells1h: Number(p.txns?.h1?.sells) || 0,
      buys5m: Number(p.txns?.m5?.buys) || 0,
      sells5m: Number(p.txns?.m5?.sells) || 0,
      priceChange5m: Number(p.priceChange?.m5) || 0,
      priceChange1h: Number(p.priceChange?.h1) || 0,
      priceChange24h: Number(p.priceChange?.h24) || 0,
      pairCreatedAt: p.pairCreatedAt || null,
      fetchedAt: Date.now()
    });
  } catch {
    return json({ available: false, source: "DexScreener" });
  }
};

export const config: Config = { path: "/api/token-stats" };
